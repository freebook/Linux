/*
   2001��6��5�� 11:04:45
   �û�: 
   ������: MAINSERVER
   ���ݿ�: imail
   Ӧ�ó���: SQL Server Enterprise Manager
*/

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
COMMIT
BEGIN TRANSACTION
ALTER TABLE dbo.gzxingxun_com ADD
	RealName varchar(50) NULL,
	Gender varchar(50) NULL,
	Birthday varchar(50) NULL,
	Question varchar(50) NULL,
	Answer varchar(50) NULL
GO
COMMIT
